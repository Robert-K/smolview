Clazz.load(["java.lang.IncompatibleClassChangeError"],"java.lang.IllegalAccessError",null,function(){
c$=Clazz.declareType(java.lang,"IllegalAccessError",IncompatibleClassChangeError);
});
