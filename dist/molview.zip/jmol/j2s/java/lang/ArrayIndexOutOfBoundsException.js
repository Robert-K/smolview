Clazz.load(["java.lang.IndexOutOfBoundsException"],"java.lang.ArrayIndexOutOfBoundsException",null,function(){
c$=Clazz.declareType(java.lang,"ArrayIndexOutOfBoundsException",IndexOutOfBoundsException);
Clazz.makeConstructor(c$,
function(index){
Clazz.superConstructor(this,ArrayIndexOutOfBoundsException,["Array index out of range: "+index]);
},"~N");
});
