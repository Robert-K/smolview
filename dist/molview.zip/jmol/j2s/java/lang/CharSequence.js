Clazz.declareInterface(java.lang,"CharSequence");
