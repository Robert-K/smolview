Clazz.load(["java.lang.Exception"],"java.lang.RuntimeException",null,function(){
c$=Clazz.declareType(java.lang,"RuntimeException",Exception);
});
