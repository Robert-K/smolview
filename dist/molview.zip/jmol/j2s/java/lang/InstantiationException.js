Clazz.load(["java.lang.Exception"],"java.lang.InstantiationException",null,function(){
c$=Clazz.declareType(java.lang,"InstantiationException",Exception);
});
