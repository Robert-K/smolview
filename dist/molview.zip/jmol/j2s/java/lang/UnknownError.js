Clazz.load(["java.lang.VirtualMachineError"],"java.lang.UnknownError",null,function(){
c$=Clazz.declareType(java.lang,"UnknownError",VirtualMachineError);
});
