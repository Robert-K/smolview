Clazz.load(["java.lang.IncompatibleClassChangeError"],"java.lang.AbstractMethodError",null,function(){
c$=Clazz.declareType(java.lang,"AbstractMethodError",IncompatibleClassChangeError);
});
