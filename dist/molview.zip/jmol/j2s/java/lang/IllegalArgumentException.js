Clazz.load(["java.lang.RuntimeException"],"java.lang.IllegalArgumentException",null,function(){
c$=Clazz.declareType(java.lang,"IllegalArgumentException",RuntimeException);
Clazz.makeConstructor(c$,
function(cause){
Clazz.superConstructor(this,IllegalArgumentException,[(cause==null?null:cause.toString()),cause]);
},"Throwable");
});
