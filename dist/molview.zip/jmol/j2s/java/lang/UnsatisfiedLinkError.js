Clazz.load(["java.lang.LinkageError"],"java.lang.UnsatisfiedLinkError",null,function(){
c$=Clazz.declareType(java.lang,"UnsatisfiedLinkError",LinkageError);
});
