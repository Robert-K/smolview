Clazz.load(null,"java.lang.Void",["java.lang.RuntimeException"],function(){
c$=Clazz.declareType(java.lang,"Void");
Clazz.defineStatics(c$,
"TYPE",null);
{
java.lang.Void.TYPE=java.lang.Void;
}});
