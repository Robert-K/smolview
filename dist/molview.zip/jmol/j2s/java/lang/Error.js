Clazz.load(["java.lang.Throwable"],"java.lang.Error",null,function(){
c$=Clazz.declareType(java.lang,"Error",Throwable);
});
