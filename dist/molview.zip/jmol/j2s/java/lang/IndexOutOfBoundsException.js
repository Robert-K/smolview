Clazz.load(["java.lang.RuntimeException"],"java.lang.IndexOutOfBoundsException",null,function(){
c$=Clazz.declareType(java.lang,"IndexOutOfBoundsException",RuntimeException);
});
