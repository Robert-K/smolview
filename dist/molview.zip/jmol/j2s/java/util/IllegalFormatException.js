Clazz.load(["java.lang.IllegalArgumentException"],"java.util.IllegalFormatException",null,function(){
c$=Clazz.declareType(java.util,"IllegalFormatException",IllegalArgumentException,java.io.Serializable);
Clazz.makeConstructor(c$,
function(){
Clazz.superConstructor(this,java.util.IllegalFormatException,[]);
});
});
