Clazz.declareInterface(java.util,"EventListener");
