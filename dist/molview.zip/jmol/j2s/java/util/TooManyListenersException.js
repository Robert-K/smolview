Clazz.load(["java.lang.Exception"],"java.util.TooManyListenersException",null,function(){
c$=Clazz.declareType(java.util,"TooManyListenersException",Exception);
});
